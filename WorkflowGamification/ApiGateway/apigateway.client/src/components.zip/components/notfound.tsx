import { Footer } from './footer';

<body>
	<div className="not-found-in-center" >
		<div>
			<p>404 NOT FOUND</p>
		</div>
	</div>
	
	<div className="footer">
		<Footer />
	</div>

</body>